var a=10;
var b=20;
var c;
c=a+b;
document.writeln(c);

sub=50-40;
document.writeln(sub);

mul=5*2;
document.writeln(mul);

div=10/2;
document.writeln(div);

mod=50%2;
document.writeln(mod);

num=10;
num++;
document.writeln(num);

num--;
document.writeln(num);
