create database T1;
use T1;
create table customer(c_id int primary key,c_name varchar(20),c_location varchar(20),c_mob varchar(100));
insert into customer values(1,'xyz','mumbai','9846476524'),
						   (2,'abc','pune','9846476525'),
                           (3,'pqr','nashik','9846476526'),
                           (4,'wer','thane','9846476527'),
                           (5,'ghs','nagpur','9846476528');
select * from customer;
# second table order:
create table order1(o_id int primary key,ordername varchar(30) not null,o_price int,c_id int,foreign key(c_id) references customer(c_id));
insert into order1 values(101,'pizza',499,3),
                         (102,'vadapav',489,4),
                         (103,'panipuri',429,5),
                         (104,'burger',399,1),
                         (105,'dabeli',499,4);
select * from order1;
select c_name,c_mob,ordername from customer,
order1 where customer.c_id=order1.c_id;
select c_name,c_location,ordername,o_price from customer,
order1 where customer.c_id=order1.c_id;
select c_name,ordername from customer,
order1 where customer.c_id=order1.c_id;
#Inner Join:
select c_name,c_location,ordername from customer inner join order1 on customer.c_id=order1.c_id;
#Right Join:
select c_name,c_location,ordername from customer right join order1 on customer.c_id=order1.c_id;
#Left Join:
select c_name,c_location,ordername from customer left join order1 on customer.c_id=order1.c_id;