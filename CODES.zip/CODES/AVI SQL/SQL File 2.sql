create database TEJAS;
use TEJAS;
create table employee1(e_id int,e_name varchar(20),e_address varchar(100),e_mob varchar(100),e_gender varchar(20),e_salary double);
select * from employee1;
insert into employee1 values(1,'harshal','thane','8737858','male',5000);
insert into employee1 values(2,'rahul','diva','7565777','male',6000);
insert into employee1 values(3,'kishor','dombivli','8737566','male',7000);
insert into employee1 values(4,'suresh','kalyan','7786990','male',8000);
update employee1 set e_mob=9467555 where e_id=3;
delete from employee1 where e_id=4;
select e_salary*12 as annual_salary from employee1;
select e_salary*100 from employee1;
select * from employee1 where e_salary=6000 and e_name='rahul'; #logical and operator
select * from employee1 where e_salary=1000 or e_name='rahul'; #logical or operator
select * from employee1 where e_name like'k%'; #first letter
select * from employee1 where e_name like'%l'; #last letter
select * from employee1 where e_name like'_i%'; #second letter
select * from employee1 where e_name like'%h%'; #any one character
select * from employee1 order by e_salary; #ascending order
select * from employee1 order by e_salary desc; #descending order
select distinct * from employee1; #remove duplicate values and information