function myfunction(){
document.getElementById("demo").innerHTML="samruddhi phadatare"}
