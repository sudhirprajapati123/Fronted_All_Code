var app = angular.module('myApp', []);
app.controller('myCtrl1', function($scope) {
  $scope.firstname1 = "Tejas";
});

app.controller('myCtrl2', function($scope) {
  $scope.firstname2 = "Chaudhari";
});
