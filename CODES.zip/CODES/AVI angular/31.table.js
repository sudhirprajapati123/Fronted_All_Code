var app = angular.module("myMod", []);
app.controller("ctrl", function($scope) {
  $scope.emp = [
    {'id':001, 'ename':'Prashant', 'designation':'Developer', 'salary':35000},
    {'id':002, 'ename':'Rahul', 'designation':'Tester', 'salary':15000},
    {'id':003, 'ename':'Suresh', 'designation':'HR', 'salary':75000},
    {'id':004, 'ename':'Nitesh', 'designation':'Trainer', 'salary':25000},
    {'id':005, 'ename':'Mukesh', 'designation':'Controller', 'salary':45000},
  ]
});
