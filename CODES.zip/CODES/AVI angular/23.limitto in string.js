var app =angular.module( 'myApp',[]);
app.controller('myCtrl1', function($scope){
$scope.a = 'Tejas';
$scope.b = 12345;
});
