var app = angular.module('myApp', []);
app.controller('myCtrl1', function($scope) {
  $scope.n = "Tejas";
  $scope.a = 0;

  $scope.m = "Rahul";
  $scope.b = 0;

  $scope.l = "Suresh";
  $scope.c = 0;

  $scope.k = "Kapil";
  $scope.d = 0;
});
