var app = angular.module("myApp", []);
app.controller("myCtrl", function($scope) {

  $scope.a = ['apple', 'cherry', 'kiwi', 'berry'];
  $scope.c = ['apple', 'cherry', 'kiwi', 'berry'];
  $scope.b = angular.equals($scope.a,$scope.c);

  $scope.f = "Tejas";
  $scope.h = angular.isString($scope.f);

  $scope.v = "g";
  $scope.s = angular.isNumber($scope.v);

  $scope.g = "Tejas";
  $scope.t = angular.lowercase($scope.g);

  $scope.m = "Tejas";
  $scope.n = angular.uppercase($scope.m);
});

