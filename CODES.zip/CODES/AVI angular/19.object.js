var app = angular.module("myapp",[]);

app.controller("myController1",function($scope){
$scope.student=[{'name':'Tejas','id':1,'city':'Pune'},
                {'name':'Rahul','id':4,'city':'Thane'},
                {'name':'Santosh','id':8,'city':'Pune'},                 {'name':'Abhishekh','id':2,'city':'Nashik'}]
});