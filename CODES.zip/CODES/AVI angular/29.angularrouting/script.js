var app = angular.module("myMod", ["ngRoute"]);
app.config(function($routeProvider) {
  $routeProvider
    .when("/page1", {
      templateUrl: "page1.htm"
    })
    .when("/page2", {
      templateUrl: "page2.htm"
    })
    .when("/page3", {
      templateUrl: "page3.htm"
    })
    .when("/index", {
      templateUrl: "index.html"
    });
});