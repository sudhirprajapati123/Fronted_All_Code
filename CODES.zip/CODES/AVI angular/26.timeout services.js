var app = angular.module('myMod', []);
app.controller('myctrl', function($scope,$interval,$timeout) {

$scope.name= "Learning services";
$timeout(function() {$scope.name = "Function is fired..";},4000);
});
