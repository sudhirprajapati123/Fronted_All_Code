var app = angular.module('myMod', []);
app.controller('myCtrl1', function($scope) {
  $scope.color = "blue";
});
app.run(function($rootScope){$rootScope.color = "red"});
