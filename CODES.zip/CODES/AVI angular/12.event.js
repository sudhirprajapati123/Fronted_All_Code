var app = angular.module('myApp', []);
app.controller('myCtrl1', function($scope) {
  $scope.number = 0;
  $scope.b = 0;
  $scope.c = 0;
  $scope.d = 0;
  $scope.e = 0;
  $scope.f = 0;
  $scope.g = 0;
  $scope.h = 0;
});
