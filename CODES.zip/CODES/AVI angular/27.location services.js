var app = angular.module("myMod", []);
app.controller("myController", function($scope, $location) {
  $scope.url = $location.absUrl();
  $scope.protocol = $location.protocol();
  $scope.host = $location.host();
  $scope.port = $location.port()
});