var app = angular.module('myApp', []);
app.controller('myCtrl1', function($scope) {
  $scope.name = "Learning filters";
  $scope.amount = "27000";
  $scope.mydate = new Date();
});
