var app = angular.module("myMod", []);
app.controller("myCtrl1", function($scope,$interval,$timeout,$window) {

  $scope.alert1=function(){$window.alert("hello world")}
  $scope.alert2=function(name){window.alert("Your Name is: " + name)}

  $scope.pro=function() {

  var fname=$window.prompt("Enter first Name");
  var lname=$window.prompt("Enter last Name");
  $window.alert("Your full name is: " + fname + " " + lname)}

  $scope.pro2=function() {

  var num1=parseInt($window.prompt("Enter first No"));
  var num2=parseInt($window.prompt("Enter last No"));
  $window.alert("Your addition is: " + (num1 + num2))}

});
