var app =angular.module( 'myApp',[]);
app.controller('myCtrl1', function($scope){
$scope.fruit =['Banana','Mango','Pineapple','Kivi','Grapes'] 
 });