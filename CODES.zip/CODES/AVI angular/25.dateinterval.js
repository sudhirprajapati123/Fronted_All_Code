var app = angular.module('myMod', []);
app.controller('myctrl', function($scope,$interval) {
$interval(function() {
$scope.mydate= Date();
});
});
