var app = angular.module('myMod', []);
app.controller('myCtrl1', function($scope,$interval) {
$scope.count = 0;
$scope.myFun = function(){
$interval(function() {
$scope.count++
}, 1000);
}
});
