show databases

create database wd13

use wd13

create table student
(
id int,
Name varchar(9),
age int
)
desc student

insert into student values(1,'Vijay',21),
						  (2,'Ashok',22),
                          (3,'samrudhi',20),
                          (4,'Neha',24),
                          (5,'Rahul',25),
                          (6,'Nikhil',26),
                          (7,'Raj',27)
                          
select *from student                    


create table emp
(
emp_id int primary key,
emp_name varchar(35),
emp_salary int
)

desc emp

insert into emp values(1,'Vijay',21000),
						  (2,'Ashok',22000),
                          (3,'samrudhi',20000),
                          (4,'Neha',24000),
                          (5,'Rahul',25000),
                          (6,'Nikhil',26000),
                          (7,'Raj',27000)

select * from emp

update emp set emp_name='krutika' where emp_id=4

delete from emp where emp_name='Raj'


desc emp1

alter table emp add date_of_joining date

alter table emp modify emp_salary double

alter table emp change emp_salary salary double
alter table emp drop date_of_joining

rename table emp to emp1

Truncate table emp1

drop table emp1

create table emp(
                empno decimal(4,0) NOT Null,
                ename varchar(10) default NULL,
                job varchar(9) default NULL,
                mgr decimal(4,0) default NULL,
                hiredate date default NULL,
                sal decimal(7,2) default NULL,
                comm decimal(7,2) default null,
                eptno decimal(2,0) default null
                );


insert into emp values('7369','smith','clerk','7902','1980-12-17','800.00',null,'20');
insert into emp values('7499','allen','salesman','7698','1981-02-20','1600.00','300.00','30');
insert into emp values('7521','ward','salesman','7698','1981-02-22','1250.00',500.00,'30');
insert into emp values('7566','jones','manager','7839','1981-04-02','2975.00',null,'20');
insert into emp values('7654','martin','salesman','7698','1980-09-28','1250.00','1400.00','20');
insert into emp values('7698','blake','manager','7839','1980-05-01','2850.00',null,'30');
insert into emp values('7782','clark','manager','7839','1980-06-09','2450.00',null,'10');
insert into emp values('7788','scott','analyst','7599','1980-12-09','3000.00',null,'20');
insert into emp values('7839','king','president',null,'1980-11-17','5000.00',null,'10');
insert into emp values('7844','turner','salesman','7698','1980-09-08','1500.00','0.00','30');
insert into emp values('7876','adams','clerk','7755','1980-01-12','1100.00',null,'20');
insert into emp values('7900','james','clerk','7698','1980-12-03','950.00',null,'30');
insert into emp values('7902','ford','analyst','7566','1980-12-03','3000.00',null,'20');
insert into emp values('7934','miller','clerk','7782','1980-01-23','1300.00',null,'10')

select  *from emp      



select ename from emp      

select ename,job,sal from emp     

select *from emp where ename='allen'
select*from emp where empno='7902'
select*from emp where job='salesman'

#logical operator
#and operator
select*from emp where ename='allen' AND empno='7499'
select*from emp where ename='blake' AND job='manager'
 
#or operator
select*from emp where ename='blake' OR job='manager'
select*from emp where sal='2000' OR sal='5000'

#between operator 
select*from emp where sal between 1000 and 3000
select*from emp where ename between 'allen' and 'king'
select*from emp where hiredate between '1980-12-17' and '1981-06-09'

#in operator 
select*from emp where ename in('james','smith','king')
select*from emp where ename not in('james','smith','king')

#like operator 
select *from emp where ename  like 's%'
select *from emp where ename  like '%s'
select *from emp where ename  like '___e%'
select*from emp where ename like'%t%u%r%'

#arithmetic operator
select sal,sal*12 from emp
select ename,sal,sal+1000 from emp
select ename,sal,sal-100 from emp
select ename,sal,sal/2 from emp

#comparision operator 
select*from emp where sal=5000
select ename,sal from emp where sal>=1390
select *from emp where sal<3000

#single row function
-> UPPER,LOWER,CONCAT,LENGTH,SUBSTR,REPLACE,ROUND,MOD,SQRT

select upper("quastech")
select upper(ename)from emp

select lower("QUASTECH")
select lower(ename) from emp

select concat("quastech","thane")
select concat(ename,sal) from emp

select length("QUASTECH")
select length("ename") from emp

select substr("quastech",2,4)

 
select round(12.23)

select mod(10,3)

#aggregate function (group function)
select avg(sal) from emp
select count(*) from emp
select max(sal) from emp
select min(sal) from emp
select sum(sal) from emp




